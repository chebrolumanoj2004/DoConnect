let accountStore = [];

function openRegister() {
    document.getElementById("authWrapper").style.display = "none";
    document.getElementById("registerWrapper").style.display = "block";
}

function backToAuth() {
    document.getElementById("registerWrapper").style.display = "none";
    document.getElementById("authWrapper").style.display = "block";
}

function createUser() {
    let u = document.getElementById("newUser").value;
    let p = document.getElementById("newPass").value;

    accountStore.push({ u, p });

    alert("Account Created Successfully!");
    backToAuth();
}

function signIn() {
    let u = document.getElementById("loginUser").value;
    let p = document.getElementById("loginPass").value;

    let found = accountStore.find(acc => acc.u === u && acc.p === p);

    if (found) {
        document.getElementById("authWrapper").style.display = "none";
        document.getElementById("dashboardArea").style.display = "block";
        window.location.hash = "";
    } else {
        alert("Incorrect Login!");
    }
}

function signOut() {
    document.getElementById("dashboardArea").style.display = "none";
    document.getElementById("authWrapper").style.display = "block";
}
