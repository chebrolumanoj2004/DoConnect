let accountStore = JSON.parse(localStorage.getItem("accounts")) || [];
let currentUser = null;

function openRegister() {
    document.getElementById("authWrapper").style.display = "none";
    document.getElementById("registerWrapper").style.display = "block";
}

function backToAuth() {
    document.getElementById("registerWrapper").style.display = "none";
    document.getElementById("authWrapper").style.display = "block";
}

function createUser() {

    let u = document.getElementById("newUser").value;
    let p = document.getElementById("newPass").value;
    let name = document.getElementById("newName").value;
    let studentClass = document.getElementById("newClass").value;
    let roll = document.getElementById("newRoll").value;
    let email = document.getElementById("newEmail").value;

    if (!u || !p || !name || !studentClass || !roll || !email) {
        alert("Please fill all fields!");
        return;
    }

    let userExists = accountStore.find(acc => acc.u === u);
    if (userExists) {
        alert("Username already exists!");
        return;
    }

    let newAccount = { u, p, name, studentClass, roll, email };

    accountStore.push(newAccount);
    localStorage.setItem("accounts", JSON.stringify(accountStore));

    alert("Account Created Successfully!");
    backToAuth();
}

function signIn() {

    let u = document.getElementById("loginUser").value;
    let p = document.getElementById("loginPass").value;

    let found = accountStore.find(acc => acc.u === u && acc.p === p);

    if (found) {
        currentUser = found;

        document.getElementById("authWrapper").style.display = "none";
        document.getElementById("dashboardArea").style.display = "block";

        loadProfileData();
        window.location.hash = "#homeView";
    } else {
        alert("Incorrect Login!");
    }
}

function loadProfileData() {

    document.getElementById("profileName").textContent = currentUser.name;
    document.getElementById("profileClass").textContent = currentUser.studentClass;
    document.getElementById("profileRoll").textContent = currentUser.roll;
    document.getElementById("profileEmail").textContent = currentUser.email;
}

function signOut() {
    document.getElementById("dashboardArea").style.display = "none";
    document.getElementById("authWrapper").style.display = "block";
}