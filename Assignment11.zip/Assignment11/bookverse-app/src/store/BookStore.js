import { EventEmitter } from "events";
import AppDispatcher from "../dispatcher/AppDispatcher";

let books = [];

class BookStore extends EventEmitter {

  getBooks() {
    return books;
  }

  addBook(book) {
    books.push(book);
    this.emit("change");
  }

}

const store = new BookStore();

AppDispatcher.register((action) => {
  switch (action.type) {
    case "ADD_BOOK":
      store.addBook(action.payload);
      break;
    default:
      break;
  }
});

export default store;