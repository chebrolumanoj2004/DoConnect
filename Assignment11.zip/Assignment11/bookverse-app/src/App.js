import React from "react";
import BookForm from "./components/BookForm";
import BookList from "./components/BookList";

function App() {
  return (
    <div className="container">
      <h1>📚 BookVerse</h1>

      <BookForm />

      <BookList />
    </div>
  );
}

export default App;