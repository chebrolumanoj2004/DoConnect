import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { addBook } from "../actions/BookActions";

const BookSchema = Yup.object().shape({
  title: Yup.string().required("Title is required"),
  author: Yup.string().required("Author is required"),
  price: Yup.number().required("Price is required")
});

function BookForm() {

  return (
    <div className="formBox">
      <h2>Add New Book</h2>

      <Formik
        initialValues={{
          title: "",
          author: "",
          price: ""
        }}

        validationSchema={BookSchema}

        onSubmit={(values, { resetForm }) => {
          addBook(values);
          resetForm();
        }}
      >
        <Form>

          <Field name="title" placeholder="Book Title" />
          <ErrorMessage name="title" component="div" className="error"/>

          <Field name="author" placeholder="Author Name" />
          <ErrorMessage name="author" component="div" className="error"/>

          <Field name="price" placeholder="Price" type="number" />
          <ErrorMessage name="price" component="div" className="error"/>

          <button type="submit">Add Book</button>

        </Form>
      </Formik>
    </div>
  );
}

export default BookForm;