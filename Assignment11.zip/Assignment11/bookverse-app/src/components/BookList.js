import React, { useEffect, useState } from "react";
import BookStore from "../store/BookStore";

function BookList() {

  const [books, setBooks] = useState([]);

  useEffect(() => {

    const updateBooks = () => {
      setBooks([...BookStore.getBooks()]);
    };

    BookStore.on("change", updateBooks);

    return () => {
      BookStore.removeListener("change", updateBooks);
    };

  }, []);

  return (
   <div className="bookCollection">
      <h2>Book Collection</h2>

      <div className="grid">
        {books.map((book, index) => (
          <div className="card" key={index}>
            <h3>{book.title}</h3>
            <p>Author: {book.author}</p>
            <p>Price: ₹{book.price}</p>
          </div>
        ))}
      </div>

    </div>
  );
}

export default BookList;