const express = require("express");
const app = express();

const PORT = 4000;

app.use(express.json());

/* Middleware Logger */
app.use((req, res, next) => {
  const time = new Date().toLocaleString();
  console.log(`[${req.method}] ${req.url} - ${time}`);
  next();
});

/* Import Books Router */
const bookRouter = require("./routes/books");

/* Home */
app.get("/", (req, res) => {
  res.send("Welcome to Express Server");
});

/* Products */
app.get("/products", (req, res) => {

  const name = req.query.name;

  if (name) {
    res.send(`Searching for product: ${name}`);
  } else {
    res.send("Please provide a product name");
  }

});

/* Books Routes */
app.use("/books", bookRouter);

/* 404 Error */
app.use((req, res) => {
  res.status(404).send("Route not found");
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});