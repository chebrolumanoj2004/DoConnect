const express = require("express");

const app = express();
const PORT = 5000;

/* Logging Middleware */
app.use((req, res, next) => {
  const time = new Date().toISOString();
  console.log(`[${req.method}] ${req.url} at ${time}`);
  next();
});

/* Built-in Middleware */
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/* View Engine */
app.set("view engine", "ejs");

/* POST route */
app.post("/users", (req, res) => {
  const user = req.body;

  res.json({
    message: "User created successfully",
    data: user
  });
});

/* Courses Page */
app.get("/courses", (req, res) => {

  const courses = [
    "Node.js",
    "React",
    "MongoDB",
    "Express"
  ];

  res.render("courses", { courses });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});