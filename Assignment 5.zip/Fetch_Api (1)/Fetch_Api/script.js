
const App = (function () {

    const output = document.getElementById("output");
    const message = document.getElementById("message");

    function clearScreen() {
        output.innerHTML = "";
        message.innerText = "";
    }

    function showLoading(text) {
        message.innerText = text;
    }

    function formatTitle(title) {
        return title.charAt(0).toUpperCase() + title.slice(1);
    }

    function formatBody(body) {
        return body.charAt(0).toUpperCase() + body.slice(1);
    }

    function displayPosts(posts) {
        posts.slice(0, 8).forEach(post => {
            const card = document.createElement("div");
            card.className = "card";

            card.innerHTML = `
                <h3>📖 ${formatTitle(post.title)}</h3>
                <p>${formatBody(post.body)}</p>
                <p class="extra">✨ This article offers meaningful insights and valuable knowledge for curious readers.</p>
            `;

            output.appendChild(card);
        });
    }

    function displayTodos(todos) {
        todos.slice(0, 8).forEach(todo => {
            const card = document.createElement("div");
            card.className = "card";

            card.innerHTML = `
                <h3>📝 ${formatTitle(todo.title)}</h3>
                <p class="status ${todo.completed ? 'completed' : 'pending'}">
                    ${todo.completed
                        ? "🎉 Task Completed Successfully!"
                        : "⏳ Pending Task – Needs Attention"}
                </p>
            `;

            output.appendChild(card);
        });
    }

    async function fetchPosts() {
        clearScreen();
        showLoading("🔄 Fetching latest articles...");

        try {
            const response = await fetch("https://jsonplaceholder.typicode.com/posts");

            if (!response.ok) {
                throw new Error();
            }

            const data = await response.json();
            message.innerText = "✅ Articles loaded successfully!";
            displayPosts(data);

        } catch (error) {
            message.innerText = "❌ Failed to load articles. Please try again.";
        }
    }

    async function fetchTodos() {
        clearScreen();
        showLoading("🔄 Fetching your task list...");

        try {
            const response = await fetch("https://jsonplaceholder.typicode.com/todos");

            if (!response.ok) {
                throw new Error();
            }

            const data = await response.json();
            message.innerText = "✅ Tasks loaded successfully!";
            displayTodos(data);

        } catch (error) {
            message.innerText = "❌ Failed to load tasks. Please try again.";
        }
    }

    return {
        loadPosts: fetchPosts,
        loadTodos: fetchTodos
    };

})();

document.getElementById("loadPosts").addEventListener("click", App.loadPosts);
document.getElementById("loadTodos").addEventListener("click", App.loadTodos);