import React, { useContext } from "react";
import { ThemeContext } from "../context/ThemeContext";

function ThemeToggle({ buttonStyle }) {

  const { theme, toggleTheme } = useContext(ThemeContext);

  return (
    <div>
      <h2>Current Theme: {theme}</h2>
      <button style={buttonStyle} onClick={toggleTheme}>
        Toggle Theme
      </button>
    </div>
  );
}

export default ThemeToggle;