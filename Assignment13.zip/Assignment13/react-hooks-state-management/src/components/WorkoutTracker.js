import React from "react";
import useTimer from "../hooks/useTimer";

function WorkoutTracker({ buttonStyle }) {

  const { time, start, stop, reset } = useTimer();

  return (
    <div>
      <h2>Workout Timer</h2>
      <h3>{time} seconds</h3>

      <button style={buttonStyle} onClick={start}>Start</button>
      <button style={buttonStyle} onClick={stop}>Stop</button>
      <button style={buttonStyle} onClick={reset}>Reset</button>
    </div>
  );
}

export default WorkoutTracker;