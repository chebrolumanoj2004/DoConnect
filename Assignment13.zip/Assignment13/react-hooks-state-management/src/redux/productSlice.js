import { createSlice } from "@reduxjs/toolkit";

const productSlice = createSlice({
  name: "products",
  initialState: {
    list: []
  },

  reducers: {

    fetchProducts: (state) => {
      state.list = [
        { id: 1, name: "Laptop", price: 50000 },
        { id: 2, name: "Mobile", price: 20000 }
      ];
    },

    updateProduct: (state, action) => {
      const index = state.list.findIndex(
        p => p.id === action.payload.id
      );

      if (index !== -1) {
        state.list[index] = action.payload;
      }
    }

  }
});

export const { fetchProducts, updateProduct } = productSlice.actions;
export default productSlice.reducer;