import React, { useEffect, useContext } from "react";
import ThemeToggle from "./components/ThemeToggle";
import WorkoutTracker from "./components/WorkoutTracker";
import { ThemeProvider, ThemeContext } from "./context/ThemeContext";

import { useDispatch, useSelector } from "react-redux";
import { fetchProducts } from "./redux/productSlice";

function MainApp() {

  const { theme } = useContext(ThemeContext);

  const dispatch = useDispatch();
  const products = useSelector((state) => state.products.list);

  useEffect(() => {
    dispatch(fetchProducts());
  }, [dispatch]);

  useEffect(() => {
    if (theme === "dark") {
      document.body.style.backgroundColor = "#121212";
      document.body.style.color = "white";
    } else {
      document.body.style.backgroundColor = "white";
      document.body.style.color = "black";
    }
  }, [theme]);

  const buttonStyle = {
    padding: "8px 15px",
    margin: "5px",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    backgroundColor: theme === "dark" ? "#ff9800" : "#4a6cf7",
    color: "white"
  };

  return (
    <div style={{ padding: "20px" }}>

      <h1>React Hooks & State Management</h1>

      <ThemeToggle buttonStyle={buttonStyle} />

      <hr />

      <WorkoutTracker buttonStyle={buttonStyle} />

      <hr />

      <h2>Products</h2>

      {products.map((p) => (
        <div key={p.id}>
          {p.name} - ₹{p.price}
        </div>
      ))}

    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <MainApp />
    </ThemeProvider>
  );
}

export default App;