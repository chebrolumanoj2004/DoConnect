console.log("Node Version:", process.version);
console.log("Current File:", __filename);
console.log("Current Directory:", __dirname);

let count = 0;

const timer = setInterval(() => {
    console.log("Welcome to Node.js");
    count++;
}, 3000);

setTimeout(() => {
    clearInterval(timer);
    console.log("Timer stopped after 10 seconds");
}, 10000);