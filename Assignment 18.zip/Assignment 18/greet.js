const name = process.argv[2];

const date = new Date();

console.log(`Hello, ${name}! Today is ${date}`);