const db = require("../config/db");

exports.createCourse = (req, res) => {
  const { name } = req.body;

  const sql = "INSERT INTO courses (name) VALUES (?)";

  db.query(sql, [name], (err, result) => {
    if (err) return res.status(500).json(err);

    res.json({ message: "Course inserted successfully" });
  });
};