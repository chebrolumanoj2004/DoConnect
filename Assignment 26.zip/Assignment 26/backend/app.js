const express = require("express");
const app = express();

const courseRoutes = require("./routes/courseRoutes");


app.use(express.json());


app.use("/api/v1/courses", courseRoutes);

app.get("/status", (req, res) => {
  res.send("App is running");
});

module.exports = app;