import { useState, useEffect } from "react";
import { io } from "socket.io-client";

const socket = io("http://localhost:5000");

function Chat() {
  const [message, setMessage] = useState("");
  const [chat, setChat] = useState([]);

  const sendMessage = () => {
    if (message.trim() === "") return;

    socket.emit("send_message", message);
    setMessage("");
  };

  useEffect(() => {
  socket.on("receive_message", (data) => {
    setChat((prev) => [...prev, data]);
  });

  return () => socket.off("receive_message");
}, []);

  return (
    <div>
      <h2>Live Chat</h2>

      <div style={{ border: "1px solid black", height: "200px", overflowY: "scroll" }}>
        {chat.map((msg, index) => (
          <p key={index}>{msg}</p>
        ))}
      </div>

      <input
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Type message"
      />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
}

export default Chat;