import { useState } from "react";
import axios from "axios";

function Upload() {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");

  const handleUpload = async () => {
    if (!file) return alert("Select a file");

    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await axios.post(
  "http://localhost:5000/api/v1/upload",
  formData,
  {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  }
);
      setMessage(res.data.message);
    } catch (err) {
      console.error(err);
      setMessage("Upload failed");
    }
  };

  return (
    <div>
  <h2>Upload PDF</h2>
  <input type="file" onChange={(e) => setFile(e.target.files[0])} />
  <button onClick={handleUpload}>Upload</button>
  <p>{message}</p>
</div>
  );
}

export default Upload;