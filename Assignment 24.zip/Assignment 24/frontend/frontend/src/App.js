import "./App.css";
import Upload from "./components/Upload";
import Chat from "./components/Chat";

function App() {
  return (
    <div className="container">
      <h1>EduConnect</h1>

      <div className="upload-box">
        <Upload />
      </div>

      <div className="chat-box">
        <Chat />
      </div>
    </div>
  );
}

export default App;