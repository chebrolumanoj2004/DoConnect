const express = require("express");
const router = express.Router();
const upload = require("../config/multerConfig");
const { uploadFile } = require("../controllers/uploadController");


router.post("/upload", (req, res) => {
  upload.single("file")(req, res, (err) => {
  
    if (err) {
      console.error("Upload Error:", err.message);
      return res.status(500).json({ message: err.message });
    }

  
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

   
    uploadFile(req, res);
  });
});

module.exports = router;