const express = require("express");
const http = require("http");
const cors = require("cors");

const uploadRoutes = require("./routes/uploadRoutes");
const initSocket = require("./socket/socket");

const app = express();
const server = http.createServer(app);

app.use(cors());
app.use(express.json());


app.use("/api/v1", uploadRoutes);


app.use("/materials", express.static("uploads"));


initSocket(server);

const PORT = 5000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});