let courses = [];
let id = 1;

exports.getCourses = (req, res) => {
  res.json(courses);
};

exports.createCourse = (req, res) => {
  const { name, duration } = req.body;

  const newCourse = {
    id: id++,
    name,
    duration,
  };

  courses.push(newCourse);
  res.json(newCourse);
};

exports.updateCourse = (req, res) => {
  const course = courses.find(c => c.id == req.params.id);

  if (!course) {
    return res.status(404).json({ error: "Course not found" });
  }

  course.name = req.body.name;
  course.duration = req.body.duration;

  res.json(course);
};


exports.deleteCourse = (req, res) => {
  courses = courses.filter(c => c.id != req.params.id);
  res.json({ message: "Course deleted" });
};