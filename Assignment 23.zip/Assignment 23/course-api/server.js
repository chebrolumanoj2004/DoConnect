const express = require("express");
const rateLimit = require("express-rate-limit");

const app = express();

app.use(express.json());


const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 5,
  message: { error: "Too many requests" },
});
app.use(limiter);


const courseRoutes = require("./routes/courseRoutes");
app.use("/api/v1/courses", courseRoutes);


const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});