const express = require("express");
const router = express.Router();

const validateCourseId = require("../Middleware/validateCourseId");

// Dynamic route
router.get("/:id", validateCourseId, (req, res) => {

    const id = req.params.id;

    res.json({
        id: id,
        name: "React Mastery",
        duration: "6 weeks"
    });

});

module.exports = router;