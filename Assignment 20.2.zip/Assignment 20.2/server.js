const express = require("express");
const courseRoutes = require("./Routes/courses");

const app = express();
const PORT = 4000;

// Root Route
app.get("/", (req, res) => {
    res.send("Welcome to SkillSphere LMS API");
});

// Use Course Routes
app.use("/courses", courseRoutes);

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});