function validateCourseId(req, res, next) {

    const id = req.params.id;

    if (isNaN(id)) {
        return res.json({ error: "Invalid course ID" });
    }

    next();
}

module.exports = validateCourseId;