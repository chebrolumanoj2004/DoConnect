const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const session = require("express-session");
const bcrypt = require("bcrypt");

const User = require("./models/User");

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

app.use(session({
  secret: "secretkey",
  resave: false,
  saveUninitialized: true
}));

// MongoDB connection
mongoose.connect("mongodb://127.0.0.1:27017/day22DB")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

// Register page
app.get("/register", (req, res) => {
  res.sendFile(__dirname + "/views/register.html");
});

// Register user
app.post("/register", async (req, res) => {

  const { name, email, password } = req.body;

  const hashedPassword = await bcrypt.hash(password, 10);

  const newUser = new User({
    name,
    email,
    password: hashedPassword
  });

  await newUser.save();

  res.send("User Registered Successfully");
});

// Login page
app.get("/login", (req, res) => {
  res.send(`
  <h2>User Login</h2>
  <form method="POST" action="/login">
  <input type="email" name="email" placeholder="Email" required/><br><br>
  <input type="password" name="password" placeholder="Password" required/><br><br>
  <button type="submit">Login</button>
  </form>
  `);
});

// Login user
app.post("/login", async (req, res) => {

  const { email, password } = req.body;

  const user = await User.findOne({ email });

  if (!user) {
    return res.send("User not found");
  }

  const match = await bcrypt.compare(password, user.password);

  if (!match) {
    return res.send("Invalid password");
  }

  req.session.user = user;

  res.send("Login Successful");
});

// Admin route
app.get("/admin", (req, res) => {

  if (!req.session.user || req.session.user.role !== "admin") {
    return res.send("Access Denied");
  }

  res.send("Welcome, Admin!");
});

app.listen(3000, () => {
  console.log("Server running on port 3000");
});