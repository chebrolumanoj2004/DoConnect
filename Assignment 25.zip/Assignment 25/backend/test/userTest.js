const request = require("supertest");
const chai = require("chai");

const expect = chai.expect;   // ✅ IMPORTANT LINE

const app = require("../app");

describe("User API", () => {
  it("should create a new user", async () => {
    const res = await request(app)
      .post("/api/users")
      .send({ name: "Manoj" });

    expect(res.status).to.equal(201);
    expect(res.body.message).to.equal("User created");
  });
});