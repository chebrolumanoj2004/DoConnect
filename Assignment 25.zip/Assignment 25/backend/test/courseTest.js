const request = require("supertest");
const chai = require("chai");
const expect = chai.expect;

const app = require("../app");

describe("Course API", () => {
  it("should get all courses", async () => {
    const res = await request(app).get("/api/courses");

    expect(res.status).to.equal(200);
    expect(res.body).to.be.an("array");
  });
});