const express = require("express");
const app = express();

app.use(express.json());

// Sample routes
app.get("/api/courses", (req, res) => {
  res.json([{ id: 1, name: "MERN" }]);
});

app.post("/api/users", (req, res) => {
  const { name } = req.body;
  res.status(201).json({ message: "User created", name });
});

// status route (for deployment)
app.get("/status", (req, res) => {
  res.send("App is live");
});

module.exports = app;