import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="navbar">
      <Link to="/home" className="logo">
        BookVerse
      </Link>
    </nav>
  );
};

export default Navbar;