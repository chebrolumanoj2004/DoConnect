import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getBook } from "../api";

const BookDetail = () => {
  const { id } = useParams();
  const [book, setBook] = useState({});

  useEffect(() => {
    getBook(id).then((res) => setBook(res.data));
  }, [id]);

  return (
    <div className="detail">
      <img src={book.image} alt={book.title} />
      <h2>{book.title}</h2>
      <p>Author: {book.author}</p>
      <p>{book.description}</p>
      <h3>Price: ₹{book.price}</h3>
    </div>
  );
};

export default BookDetail;