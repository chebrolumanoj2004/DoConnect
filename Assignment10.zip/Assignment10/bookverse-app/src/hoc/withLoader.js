import React from "react";
import Spinner from "../components/Spinner";

const withLoader = (WrappedComponent) => {
  return function LoaderComponent({ loading, ...props }) {
    if (loading) {
      return <Spinner />;
    }
    return <WrappedComponent {...props} />;
  };
};

export default withLoader;