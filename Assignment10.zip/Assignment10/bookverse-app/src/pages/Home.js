import React, { useEffect, useState } from "react";
import { getBooks } from "../api";
import BookList from "../components/BookList";
import withLoader from "../hoc/withLoader";
import Greeting from "../renderProps/Greeting";

const BookListWithLoader = withLoader(BookList);

const Home = () => {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getBooks().then((res) => {
      setBooks(res.data);
      setLoading(false);
    });
  }, []);

  return (
    <div>
      <Greeting name="Reader">
        {(message) => <h2>{message}</h2>}
      </Greeting>

      <BookListWithLoader loading={loading} books={books} />
    </div>
  );
};

export default Home;