import axios from "axios";

const API = "http://localhost:5000/books";

export const getBooks = () => axios.get(API);
export const getBook = (id) => axios.get(`${API}/${id}`);