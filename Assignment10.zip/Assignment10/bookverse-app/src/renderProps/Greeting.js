import React from "react";

const Greeting = ({ name, children }) => {
  return (
    <div style={{ marginBottom: "20px" }}>
      {children(`Welcome ${name}! Enjoy exploring books 📚`)}
    </div>
  );
};

export default Greeting;