-- USER STORY 1 : DATABASE SETUP --

CREATE DATABASE TechNovaDB;
USE TechNovaDB;

CREATE TABLE Department(
DeptID INT PRIMARY KEY,
DeptName VARCHAR(50),
Location VARCHAR(50)
);

CREATE TABLE Employee(
EmpID INT PRIMARY KEY,
EmpName VARCHAR(100),
Gender CHAR(1),
DOB DATE,
HireDate DATE,
DeptID INT,
FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);

CREATE TABLE Project(
ProjectID INT PRIMARY KEY,
ProjectName VARCHAR(100),
DeptID INT,
StartDate DATE,
EndDate DATE,
FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);

CREATE TABLE Performance(
EmpID INT,
ProjectID INT,
Rating INT,
ReviewDate DATE,
PRIMARY KEY (EmpID,ProjectID),
FOREIGN KEY (EmpID) REFERENCES Employee(EmpID),
FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID)
);

CREATE TABLE Reward(
EmpID INT,
RewardMonth DATE,
RewardAmount DECIMAL(10,2),
FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);

 
-- USER STORY 2 : DATA MANAGEMENT --

INSERT INTO Department VALUES
(101,'IT','Bangalore'),
(102,'HR','Delhi'),
(103,'Finance','Mumbai'),
(104,'Marketing','Hyderabad'),
(105,'Operations','Chennai');

INSERT INTO Employee VALUES
(1,'Asha','F','1990-07-12','2018-06-10',101),
(2,'Raj','M','1988-04-09','2020-03-22',102),
(3,'Neha','F','1995-01-15','2021-08-05',101),
(4,'Arjun','M','1992-03-10','2019-07-19',103),
(5,'Priya','F','1994-11-22','2022-04-12',104);

UPDATE Employee
SET DeptID = 105
WHERE EmpID = 5;

DELETE FROM Reward
WHERE RewardAmount < 1000;


-- USER STORY 3 : INSIGHTS --

SELECT *
FROM Employee
WHERE HireDate > '2019-01-01';

SELECT d.DeptName,
AVG(p.Rating) AS AvgRating
FROM Department d
JOIN Employee e ON d.DeptID = e.DeptID
JOIN Performance p ON e.EmpID = p.EmpID
GROUP BY d.DeptName;

SELECT EmpName,
TIMESTAMPDIFF(YEAR, DOB, CURDATE()) AS Age
FROM Employee;

SELECT SUM(RewardAmount)
FROM Reward;


-- USER STORY 4 : JOINS --

SELECT e.EmpName,
d.DeptName,
p.ProjectName,
pf.Rating
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Performance pf ON e.EmpID = pf.EmpID
JOIN Project p ON pf.ProjectID = p.ProjectID;

SELECT EmpName
FROM Employee
WHERE EmpID NOT IN
(
SELECT EmpID FROM Reward
);



--USER STORY 5 : TRANSACTION--

START TRANSACTION;

INSERT INTO Employee VALUES
(6,'Kiran','M','1996-06-12','2024-02-01',101);

COMMIT;