
function register() {
    const username = document.getElementById("regUser").value;
    const password = document.getElementById("regPass").value;

    const user = { username, password };

    localStorage.setItem("studentUser", JSON.stringify(user));
    alert("Registered Successfully!");
}


function login() {
    const username = document.getElementById("loginUser").value;
    const password = document.getElementById("loginPass").value;

    const savedUser = JSON.parse(localStorage.getItem("studentUser"));

    if (savedUser && savedUser.username === username && savedUser.password === password) {
        localStorage.setItem("currentStudent", username);
        window.location.href = "dashboard.html";
    } else {
        alert("Invalid Login!");
    }
}


if (window.location.pathname.includes("dashboard.html")) {
    const name = localStorage.getItem("currentStudent");
    if (!name) window.location.href = "index.html";
    document.getElementById("studentName").innerText = name;
}

function goToActivity() {
    window.location.href = "activity.html";
}

function logout() {
    localStorage.removeItem("currentStudent");
    window.location.href = "index.html";
}


const activities = [
    { id: 1, activity: "Tables 12 to 19", subject: "Maths" },
    { id: 2, activity: "Science Project Model", subject: "Science" },
    { id: 3, activity: "Essay Writing", subject: "English" },
    { id: 4, activity: "Algebra Practice", subject: "Maths" }
];

if (window.location.pathname.includes("activity.html")) {
    displayActivities(activities);
}

function displayActivities(data) {
    const list = document.getElementById("activityList");
    list.innerHTML = "";
    data.forEach(item => {
        list.innerHTML += `<li>${item.activity} - (${item.subject})</li>`;
    });
}


function filterActivities() {
    const subject = document.getElementById("subjectFilter").value;

    if (subject === "All") {
        displayActivities(activities);
    } else {
        const filtered = activities.filter(a => a.subject === subject);
        displayActivities(filtered);
    }
}

function backToDashboard() {
    window.location.href = "dashboard.html";
}