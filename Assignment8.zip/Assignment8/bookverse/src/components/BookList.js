import React, { useState } from "react";
import BookCard from "./BookCard";
import "./BookList.css";

const BookList = () => {
  const [viewMode, setViewMode] = useState("grid");
  const [searchTerm, setSearchTerm] = useState("");

  const books = [
    { id: 1, title: "I cannot say goodbye to you", author: "Rithvik singh", price: 499 },
    { id: 2, title: "We are there for each other", author: "Robert Kiyosaki", price: 399 },
    { id: 3, title: "The Alchemist", author: "Paulo Coelho", price: 299 },
    { id: 4, title: "Think and Grow Rich", author: "Napoleon Hill", price: 350 },
  ];

  const filteredBooks = books.filter((book) =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container">
      
      
      <div className="controls">
        <button onClick={() => setViewMode("grid")}>Grid View</button>
        <button onClick={() => setViewMode("list")}>List View</button>
      </div>

     
      <input
        type="text"
        placeholder="Search books..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="search-box"
      />

      
      <div className={viewMode === "grid" ? "grid-layout" : "list-layout"}>
        {filteredBooks.map((book) => (
          <BookCard
            key={book.id}
            title={book.title}
            author={book.author}
            price={book.price}
            viewMode={viewMode}
          />
        ))}
      </div>
    </div>
  );
};

export default BookList;