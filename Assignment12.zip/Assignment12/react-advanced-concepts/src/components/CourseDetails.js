import React from "react";

function CourseDetails() {
  return (
    <div className="card">
      <h3>React Course</h3>
      <p>Learn React from basics to advanced.</p>
    </div>
  );
}

export default CourseDetails;