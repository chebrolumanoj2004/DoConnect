import React from "react";

function BrokenComponent() {
  throw new Error("Component crashed!");
}

export default BrokenComponent;