import React from "react";
import ReactDOM from "react-dom";

function Modal({ children, close }) {

  return ReactDOM.createPortal(

    <div className="modalOverlay">
      <div className="modal">
        {children}
        <button onClick={close}>Close</button>
      </div>
    </div>,

    document.getElementById("modal-root")
  );
}

export default Modal;