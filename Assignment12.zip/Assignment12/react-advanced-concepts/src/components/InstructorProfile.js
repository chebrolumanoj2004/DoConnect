import React from "react";

function InstructorProfile() {
  return (
    <div className="card">
      <h3>Instructor</h3>
      <p>John Doe - Senior React Developer</p>
    </div>
  );
}

export default InstructorProfile;