import React, { useState, lazy, Suspense } from "react";
import StatsCard from "./components/StatsCard";
import ErrorBoundary from "./components/ErrorBoundary";
import BrokenComponent from "./components/BrokenComponent";
import Modal from "./components/Modal";

const CourseDetails = lazy(() => import("./components/CourseDetails"));
const InstructorProfile = lazy(() => import("./components/InstructorProfile"));

function App() {
  const [showCourse, setShowCourse] = useState(false);
  const [showInstructor, setShowInstructor] = useState(false);
  const [stats, setStats] = useState([
    { id: 1, title: "Users", value: 100 },
    { id: 2, title: "Courses", value: 20 }
  ]);

  const [openModal, setOpenModal] = useState(false);

  const updateStats = () => {
    setStats(prev =>
      prev.map(stat =>
        stat.id === 1 ? { ...stat, value: stat.value + 1 } : stat
      )
    );
  };

  return (
    <div className="container">

      <h1>React Advanced Concepts</h1>

      <h2>Lazy Loading</h2>

      <button onClick={() => setShowCourse(true)}>View Course Details</button>
      <button onClick={() => setShowInstructor(true)}>View Instructor</button>

      <Suspense fallback={<p>Loading...</p>}>
        {showCourse && <CourseDetails />}
        {showInstructor && <InstructorProfile />}
      </Suspense>


  
      <h2>Stats Dashboard</h2>

      <button onClick={updateStats}>Simulate Update</button>

      <div className="grid">
        {stats.map(stat => (
          <StatsCard key={stat.id} title={stat.title} value={stat.value} />
        ))}
      </div>


      <h2>Error Boundary</h2>

      <ErrorBoundary>
        <BrokenComponent />
      </ErrorBoundary>


      
      <h2>React Portal Modal</h2>

      <button onClick={() => setOpenModal(true)}>Open Modal</button>

      {openModal && (
        <Modal close={() => setOpenModal(false)}>
          <h3>This is a Portal Modal</h3>
          <p>Rendered outside root DOM</p>
        </Modal>
      )}

    </div>
  );
}

export default App;