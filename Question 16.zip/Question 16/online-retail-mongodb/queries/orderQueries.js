db.orders.find();

db.orders.find({ userId: ObjectId("65ab1234cd567890ef123456") });


db.orders.find({ status: "Delivered" });


db.orders.find({
  orderDate: { $gt: new Date("2026-01-01") }
});


db.orders.countDocuments();


db.orders.find().sort({ orderDate: -1 });