db.users.find();


db.users.findOne({ email: "manoj@example.com" });

db.users.insertOne({
  username: "john",
  email: "john@example.com",
  passwordHash: "hashedpassword123"
});

db.users.updateOne(
  { username: "john" },
  { $set: { email: "johnnew@example.com" } }
);


db.users.deleteOne({ username: "john" });