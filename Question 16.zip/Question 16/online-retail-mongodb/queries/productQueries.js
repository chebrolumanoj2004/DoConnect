db.products.find();

db.products.find({ category: "Electronics" });

db.products.find({ price: { $lt: 500 } });

db.products.find({ stock: { $gt: 0 } });


db.products.find({ $text: { $search: "iPhone" } });

db.products.find().sort({ price: 1 });

db.products.find().limit(5);