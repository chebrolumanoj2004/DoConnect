db.products.createIndex({ category: 1 });

db.products.createIndex({ name: "text" });

db.orders.createIndex({ userId: 1 });

db.users.createIndex({ email: 1 }, { unique: true });
