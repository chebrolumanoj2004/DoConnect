const fs = require("fs");

console.log("Reading file...");

fs.readFile("data.txt", "utf8", (err, data) => {
    if (err) {
        console.log("Error:", err);
        return;
    }

    console.log("File Content:", data);

    setTimeout(() => {
        console.log("Read operation completed");
    }, 1000);
});

console.log("Program continues running...");